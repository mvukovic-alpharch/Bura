"""Projections demo — no data needed. Run: python -m projections.demo

Shows: per-sport prop pricing with the right distribution, how opponent/pace
adjust the line, and an honest correlated same-game parlay.
"""
from __future__ import annotations

from .engine import project_stat, price_line
from .sports_config import config_for
from .parlay import ParlayLeg, score_parlay


def _price(sport, player, stat, base_mean, line, opp=1.0, pace=1.0):
    cfg = config_for(sport, stat)
    proj = project_stat(player, stat, sport, base_mean, cfg["family"],
                        opp_factor=opp, pace_factor=pace,
                        sd=base_mean * cfg.get("sd_frac", 0.3) if cfg["family"] == "normal" else None,
                        dispersion=cfg.get("dispersion", 0.25))
    return price_line(proj, line)


def main():
    print("=" * 70)
    print("PROJECTION ENGINE — calibrated prop probabilities")
    print("=" * 70)

    print("\n  NFL — distribution family matters:")
    for player, stat, mean, line in [
        ("QB1", "pass_yds", 268, 249.5),
        ("QB1", "pass_tds", 1.8, 1.5),
        ("RB1", "rush_yds", 74, 64.5),
        ("WR1", "receptions", 5.4, 4.5),
    ]:
        r = _price("NFL", player, stat, mean, line)
        print(f"    {stat:<11} mean {r['mean']:>6} line {line:>6} "
              f"-> over {r['p_over']*100:>5.1f}%  (fair {r['fair_over_odds']})")

    print("\n  NBA — opponent + pace adjustment on the SAME player:")
    base = 26.5
    for label, opp, pace in [("neutral", 1.0, 1.0),
                             ("weak D + fast pace", 1.08, 1.06),
                             ("elite D + slow pace", 0.90, 0.95)]:
        r = _price("NBA", "Wing1", "points", base, 24.5, opp, pace)
        print(f"    {label:<22} proj mean {r['mean']:>5} "
              f"-> over 24.5 = {r['p_over']*100:>5.1f}%")

    print("\n  EPL — low-mean counts use Poisson:")
    for stat, mean, line in [("shots_on_target", 1.3, 0.5),
                             ("goals", 0.55, 0.5),
                             ("shots", 2.8, 2.5)]:
        r = _price("EPL", "Striker1", stat, mean, line)
        print(f"    {stat:<16} mean {r['mean']:>5} line {line} "
              f"-> over {r['p_over']*100:>5.1f}%  push {r['p_push']*100:.1f}%")

    print("\n" + "=" * 70)
    print("CORRELATED PARLAY — the thing casual bettors get wrong")
    print("=" * 70)
    # same-game: QB passing yds + his WR receiving yds = correlated
    qb = _price("NFL", "QB1", "pass_yds", 268, 249.5)
    wr = _price("NFL", "WR1", "rec_yds", 78, 69.5)
    legs = [
        ParlayLeg("QB1 over 249.5 pass yds", qb["p_over"], group="game1"),
        ParlayLeg("WR1 over 69.5 rec yds", wr["p_over"], group="game1"),
    ]
    s = score_parlay(legs, payout_odds=3.5)
    print(f"\n  Leg 1: QB over 249.5  = {qb['p_over']*100:.1f}%")
    print(f"  Leg 2: WR over 69.5   = {wr['p_over']*100:.1f}%")
    print(f"\n  Naive (independent):  {s['naive_prob']*100:.1f}%  <- parlay calc says this")
    print(f"  Correlated (honest):  {s['correlated_prob']*100:.1f}%  "
          f"({s['correlation_effect']:+.0f}% vs naive)")
    print(f"  Fair odds: {s['fair_odds']}")
    print("\n  Correlation CHANGES the true joint probability vs the naive")
    print("  product — and the direction depends on where the lines sit vs")
    print("  the means. You must COMPUTE it, not assume 'same game = higher'.")
    print("  The naive parlay calculator ignores this entirely; you don't.")


if __name__ == "__main__":
    main()
